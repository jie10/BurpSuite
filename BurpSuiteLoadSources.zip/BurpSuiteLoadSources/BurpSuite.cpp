﻿
#include "Resource.h"
#include <windows.h>

#define WIN32_LEAN_AND_MEAN

void BurpSuite(void)
{
	STARTUPINFO si = { 0 };
	PROCESS_INFORMATION pi = { 0 };
	si.cb = sizeof(si);
	si.wShowWindow = SW_HIDE;
	TCHAR BurpSuite[] = TEXT("jre/bin/java -noverify -Dsun.java2d.uiScale.enabled=true -javaagent:BurpSuiteLoader.jar -jar burpsuite_pro.jar");

	CreateProcess(NULL,
		BurpSuite,
		NULL,
		NULL,
		FALSE,
		DETACHED_PROCESS,
		NULL,
		NULL,
		&si,
		&pi);

	CloseHandle(pi.hProcess);
	CloseHandle(pi.hThread);
	return;
}

int WINAPI WinMain(_In_ HINSTANCE hInstance, _In_opt_ HINSTANCE hPreInstance, _In_ LPSTR lpCmdLine, _In_ int nShowCmd)
{
	BurpSuite();
	return 0;
}